package com.example.demo.entities;

public enum Role {

	USER,
	ADMIN
}
